package com.example.BeARescuer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class SearchActivity extends AppCompatActivity {
private Button BackS;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        Spinner mySpinner = (Spinner) findViewById(R.id.spinner1);
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>
                (SearchActivity.this, android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.Type));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(myAdapter);

        Spinner Spinner2 = (Spinner) findViewById(R.id.spinner2);
        ArrayAdapter<String> Adapter2 = new ArrayAdapter<String>
                (SearchActivity.this, android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.FurColor));
        Adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner2.setAdapter(Adapter2);

        Spinner Spinner3 = (Spinner) findViewById(R.id.spinner3);
        ArrayAdapter<String> Adapter3 = new ArrayAdapter<String>
                (SearchActivity.this, android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.EyeColor));
        Adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner3.setAdapter(Adapter3);

        Spinner Spinner4 = (Spinner) findViewById(R.id.spinner4);
        ArrayAdapter<String> Adapter4 = new ArrayAdapter<String>
                (SearchActivity.this, android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.Age));
        Adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner4.setAdapter(Adapter4);
        BackS=findViewById(R.id.button5);
        BackS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inin=new Intent(SearchActivity.this,MainActivity.class);
                startActivity(inin);
            }
        });

    }
}