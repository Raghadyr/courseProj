package com.example.BeARescuer;

import androidx.annotation.NonNull;
import
        androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

 private Button search;
 private Button Reportananimal;
 private Button goToHistory;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.maps);
        mapFragment.getMapAsync(this);
        search=findViewById(R.id.button4);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in=new Intent(MainActivity.this,SearchActivity.class);
                startActivity(in);
            }
        });
        Reportananimal=findViewById(R.id.button3);
        Reportananimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inn=new Intent(MainActivity.this,MainActivityReport.class);
                startActivity(inn);
            }
        });

        goToHistory=findViewById(R.id.goToHistory);
        goToHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inn=new Intent(MainActivity.this,ReportHistory.class);
                startActivity(inn);
            }
        });
    }



    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {

    }
}