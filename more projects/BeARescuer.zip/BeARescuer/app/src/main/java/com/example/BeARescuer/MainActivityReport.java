package com.example.BeARescuer;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.os.Bundle;
import android.content.Intent;

public class MainActivityReport extends AppCompatActivity {
    private Button submit;
    private Button BackR;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_report);
        submit=findViewById(R.id.buttonReport);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentt=new Intent(MainActivityReport.this,Contact.class);
                startActivity(intentt);
            }
        });
        BackR=findViewById(R.id.button21);
        BackR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent innn =new Intent(MainActivityReport.this,MainActivity.class);
                startActivity(innn);
            }
        });
    }
}