import java.util.*;
public class MainAssignment2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int N;
		
		System.out.println("Welcom to our project :)");
		System.out.println("Please Enter the size and numbre of queens: ");
		N=sc.nextInt();
		System.out.println("Please Enter the number of the algorithm you want: ");
		System.out.println("1- BFS ");
		System.out.println("2- IDS ");
		System.out.println("3- A* ");
		int Alg;
		Alg=sc.nextInt();
		switch (Alg) {
		case 1:
			BFS2 bfs=new BFS2(N);
			boolean result=bfs.SearchByBFS();
			break;
		case 2:
			Integer[][] temp = new Integer[N][N];

	        for (int i = 0; i < N; i++) {
	            for (int j = 0; j <N ; j++) {
	                if(i==0)
	                temp[i][j]=1;
	                else
	                    temp[i][j]=0;
	                
	            }
	        }
	    
	        Node node=new Node(temp);
			IDS ids=new IDS(node);
			ids.iterative_deeping();
			break;
		case 3:{
			Integer[][] temp2 = new Integer[N][N];

	        for (int i = 0; i < N; i++) {
	            for (int j = 0; j <N ; j++) {
	                if(i==0)
	                temp2[i][j]=1;
	                else
	                    temp2[i][j]=0;
	                
	            }
	        }
	
			
			
			Astar Astar=new Astar(temp2,N);
			Astar.searchByAstar();
			}
			break;
		
		}
		// TODO Auto-generated method stub

	}

}
