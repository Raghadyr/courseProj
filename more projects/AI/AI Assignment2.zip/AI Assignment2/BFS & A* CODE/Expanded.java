import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class Expanded {


    public List<Node> expand(Node node){//returns a list of possible states that can be reached
        List<Node> list = new ArrayList<>();
        node.createChild(node.state.length);
        for (int i = 0; i < node.children.length; i++) {
            list.add(node.children[i]);
        }

        return list;
    }

}
