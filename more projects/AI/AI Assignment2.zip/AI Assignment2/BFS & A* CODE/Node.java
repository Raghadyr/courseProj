import java.util.ArrayList;
import java.util.List;

public class Node {
    Integer[][] state;
    Node[] children;
    List<Node> childrenList;
    Node parent;
    int depth;
    int cost;
    int maxCost;
    String stringState;
    Node(){
    	
    }
    public Node(Integer[][] state) {
        children = new Node[state.length];
        this.state = state; // the state
        this.depth = 1; // the depth
        this.childrenList = new ArrayList<>(); //the children of the node
        this.parent = null;
        this.cost = 0;
        this.maxCost = 0;


    }
    Node( int n ){
    	 //set initial state 
    	 state=new Integer[n][n];
		  for (int i = 0; i <n ; i++) 
			  state[0][i]=1;
		  
		  for (int i = 1; i < n; i++) {
			  for (int j=0;j<n;j++)
				  state[i][j]=0;}
    	 
     }
     

    public boolean isGoal() {
        boolean flag = false;
        int queenNum=0;
      
        for (int i = 0; i < state.length; i++) {
            for (int j = 0; j < state.length; j++) {
                if (this.state[i][j] == 1){
                flag = isAttacked(this.state, i, j,state.length );
                if (!flag)
                    queenNum++;
            }

            }

        }
        //System.out.println(queenNum);
        return queenNum == state.length;
    }



    public boolean isAttacked(Integer[][] x, int r, int c, int N)
    {

        for(int i =0;i<N;i++)
        {
            if(x[r][i]==1 && i!=c){
                return true;
            }
        }

        for(int i =0;i<N;i++)
        {
            if(x[i][c]==1 && i!=r){
                return true;
            }
        }

        for(int i=0;i<N;i++)
        {
            for(int j=0;j<N;j++)
            {
                int a = Math.abs(r-i);
                int b = Math.abs(c-j);
                if(a==b && x[i][j]==1 &&i!=r && j!=c){
                    return true;
                }
            }

        }
        return false;
    }

    public void createChild(int n) {

        for (int i = 0; i < n; i++) {
            children[i] = new Node(this.state);
            children[i].setCost(this.cost);
            addChild(children[i]);
        }
        for (int j = 0; j < n; j++) {//shift one coulem dawn

            for (int i = 0; i < n - 1; i++) {
                if (children[j].state[i][j] == 1) {
                    children[j].state[i + 1][j] = state[i][j];
                    children[j].state[i][j] = 0;
                    break;
                }


                }
            for (int b = 0; b < state.length; b++) { //this equals to the row in our matrix.
                for (int c = 0; c < state.length; c++) { //this equals to the column in each row.
                    System.out.print(this.children[j].state[b][c] + " ");
                }
                System.out.println(); //change line on console as row comes to end in the matrix.
            }
        }
    }


    public void addChild(Node child) { //adding a Child to the node
        child.setParent(this);
        child.setDepth(this.getDepth() + 1);
        child.setMaxCost(child.getCost());
        this.childrenList.add(child);

    }

    public void setCost(int i) {                    //setting cost
        this.cost = i;
    }

    public void setMaxCost(int i) {
        this.maxCost = this.getParent().getMaxCost() + i;            //setting MaxCost
    }

    public Integer[][] getMatrix() { //getting the state in array form
        return state;
    }

    public int getMaxCost() { //getting the current MaxCode to get to current Node
        return maxCost;
    }

    public int getCost() { //getting the cost of last move
        return this.cost;
    }

    public void setParent(Node parent) { //setting the Parent of the node
        this.parent = parent;
    }

    public Node getParent() {  //getting the Parent of the node
        return parent;
    }

    public int getDepth() {  //getting the Depth of the node
        return depth;
    }

    public void setDepth(int depth) {  //setting the Depth of the node
        this.depth = depth;
    }

 Node addQueen1(Integer[][] board, int num){
    	
    	int x;
    	int xx=0;
    	Node temp= new Node();
    	temp.state=new Integer [num][num];
        for(int i=0;i<num;i++){
            for(int j=0;j<num;j++){
              
                
                	  
                        for(x = 0; x < num; x++){
                            for(xx = 0; xx < num; xx++){
                                temp.state[x][xx] = board[x][xx];
                            }
                        }if(i!=x && j!= xx)
                        temp.state[i][j] = 1;
                    
            }
        }
        return temp;
    }


}
