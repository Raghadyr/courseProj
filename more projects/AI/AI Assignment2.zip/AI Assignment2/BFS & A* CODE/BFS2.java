

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

public class BFS2 {
	
	public Node initialNode;
	int [] explored_set;
	LinkedList frontier =new LinkedList();
	int N;
	
	public BFS2(int n) {
		
		this.N=n;
		initialNode= new Node(N);
		System.out.println("After node initial");
	}
	
	
	public boolean SearchByBFS() {
		
		Info info = new Info(); // a class that has the visited HashMap, Queue, time and space

		Node node = initialNode; 
		info.queue.add(node);  //start Node is added to queue
		frontier.add(node);
		int count=0;
		while(!(info.queue.isEmpty()) && count<N ) {   //loop keeps going as long as queue is not empty
			count++;
			 node = info.queue.remove(); 
			 frontier.remove(node);
			 //remove or pop the node and begin timer
			 info.incTime();
			info.visited.put(node.hashCode(), node);   //places node in visited hashMap
			////Goal
			if (node.isGoal()) {  //if goal is found, a path is created and a path is printed
				System.out.println("The fringe size is = " + info.getSpace()  );
				System.out.println("The cost of solution is = " + N  );
				System.out.println("The cost of the search  is = " +  info.getTime() );
				for(int i=0;i<N;i++) {
					for(int j=0;j<N;j++) {
						System.out.print(node.state[i][j]+" ");
					}
					System.out.println();
				}
				return true;
			} 
			//if it is not the goal generate children
			
			Node[] list=new Node[N];
			for(int i=0;i<N;i++){
				list[i]= node.addQueen1(node.state,N);
				frontier.add(list[i]);
				
				boolean ans = info.visited.containsKey(list[i].hashCode());
				if(ans==false ){
					if(!(info.queue.contains(list[i]))) {
					info.queue.add(list[i]);
					info.queueSize();
					}
				}
			}
			

		}

		System.out.println("The fringe size is = " + info.getSpace()  );
		System.out.println("The cost of solution is = " + info.getTime()  );
		System.out.println("The cost of the search  is = " +  info.getTime() );
		for(int i=0;i<N;i++) {
			for(int j=0;j<N;j++) {
				System.out.print(node.state[i][j]+" ");
			}
			System.out.println();}
		return false;
	}
	
	
}
