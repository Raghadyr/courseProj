import java.util.List;
import java.util.Stack;
import java.util.Queue;


public class IDS  {
    private Node initialNode;
int count=0;
    public IDS(Node node) {
        this.initialNode = node;
    }


    public boolean iterative_deeping() {
        Info info = new Info();
        Node node = initialNode;
        int depth=0;
        boolean succses = false;
        int c=0;
        while (c<100000000){
            succses=depth_limted(depth,node,info);
            if (succses)
                break;
            depth++;
            c++;
        }
        return succses;
    }
    public boolean depth_limted(int depth,Node node,Info info) {


        Stack<Node> frontier = new Stack<>();


        frontier.push(node);
        while (!(frontier.isEmpty()) && node.depth <= depth && count<=8) {
        	count++;
        	
            node = frontier.pop();
            info.incTime();
            info.visited.put(node.hashCode(), node);//places node in visited hashMap

            if (node.isGoal()) {//may cuse a proplem
                PathActions p=new PathActions(initialNode,node,info);
                p.printPath();
                return true;
                //increment number of nodes
            }

            //here is the problem

            Expanded e = new Expanded();
            List<Node> list = e.expand(node);

            for (Node temp : list) {
                boolean ans = info.visited.containsKey(temp.hashCode());//hash code is the internal address of object
                if (ans == false) {
                    if (!frontier.contains(temp)) {
                        frontier.push(temp);
                        info.stackSize();
                    }
                }

            }


        }
    return false;
    }

}
