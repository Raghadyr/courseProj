import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.PriorityQueue;


public class Astar{
int numqueen;
   public Node initialNode;
   public Integer[][] N, counter;
	
   public Astar(Integer[][] N,int numqueen) {
	   this.numqueen=numqueen;
     this.N= N;
		initialNode= new Node(N);
	   }
   
	
   
   public boolean searchByAstar() {
   
   		//Astar search which creates a priority queue which sorts according to h(n)
      Info info = new Info(); // a class that has the visited HashMap, Queue, time and space
      Node node = initialNode; 
      info.pQueue.add(node);  
     
      while(!(info.pQueue.isEmpty())) {
    	 
         node = info.pQueue.poll();
         info.incTime();
         info.visited.put(node.hashCode(), node);
         if(node.isGoal()) {
            System.out.println("The fringe size is = " + info.getSpace()  );
            System.out.println("The cost of steps is = " + info.getTime()  );
            for(int i=0; i < numqueen; i++) {
               for(int j=0; j < numqueen; j++) {
                  System.out.print(node.state[i][j]+" ");
               }
               System.out.println();
            }
            return true;
         } 
      }
      
      //if it is not the goal generate children
  	Node[] list=new Node[numqueen];
	for(int i=0;i<numqueen;i++){
		list[i]= node.addQueen1(node.state,numqueen);
			for(Node temp: list) {
				System.out.println("in loop A*");
				boolean ans = info.visited.containsKey(temp.hashCode());
				if(ans==false ){
					if(!(info.pQueue.contains(temp))) {
					info.pQueue.add(temp);
					info.pQueueSize();
              
					}
				}
			}

     
      
      for(int j=0; j<numqueen;j++) {
         boolean ans = info.visited.containsKey(list[j].hashCode()); //Uses temporary node's hashCode to check if it has been expanded or not.
         if(ans==false) { //if it hasn't been expanded then we can now check if there is a node in the Priority Queue with a higher Cost
            if(!(info.pQueue.contains(list[j]))){
               info.pQueue.add(list[j]);
               info.pQueueSize();
            }
         
         }
      }
      return false;}
	return true;
   }
   
   public int compare(Node a, Node b) {
			return (a.getMaxCost() + 8) - (b.getMaxCost()+8) ;
		} 
}