import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.Stack;

public class ExpandedIDS {


    public Stack<NodeIDS> expand(NodeIDS node){//returns a list of possible states that can be reached
        Stack<NodeIDS> list = new Stack<>();
        createChild(node.state.length,node);
        for (int i = 0; i < node.children.length; i++) {
            list.push(node.children[i]);
        }

        return list;
    }

    public void createChild(int n,NodeIDS node) {
        int[][] tem={{0,1,0,0},{0,0,0,1},{1,0,0,0},{0,0,1,0}};
        int[][] temp = new int[node.state.length][node.state.length];
        /*temp =state; <- we dont want our code to copy the address and make change so that why we will use loop to transfer the elements*/


        for (int a = 0; a < node.state.length; a++) {
            System.arraycopy(node.state[a], 0, temp[a], 0, node.state.length);
        }

        for (int i = 0; i < n; i++) {


            for (int j = 0; j < temp.length-1; j++) {
                if(temp[j][i] == 1) {
                    temp[j + 1][i] = temp[j][i];
                    temp[j][i] = 0;
                    break;
                }
            }

            node.children[i] = new NodeIDS(node.state.length);
            for (int a = 0; a < node.state.length; a++) {
                for (int b = 0; b < node.state.length; b++) {
                    node.children[i].state[a][b]=temp[a][b];
                }
            }

            node.children[i].setCost(node.cost);
            node.addChild(node.children[i]);
            node.children[i].depth++;
            //temp= new Integer[][]{{1, 1, 1, 1}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}};
            for (int a = 0; a < node.state.length; a++) {
                System.arraycopy(node.state[a], 0, temp[a], 0, node.state.length);
            }

            for (int b = 0; b < node.state.length; b++) { //this equals to the row in our matrix.
                for (int c = 0; c < node.state.length; c++) { //this equals to the column in each row.
                    System.out.print(node.children[i].state[b][c] + " ");
                }
                System.out.println(); //change line on console as row comes to end in the matrix.
            }

        }



    }

}
