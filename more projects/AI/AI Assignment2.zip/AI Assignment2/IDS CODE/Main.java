import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.println("Enter N: ");
        int n=input.nextInt();
        //bored initial state
        int[][] tem={{0,1,0,0},{0,0,0,1},{1,0,0,0},{0,0,1,0}};
        int[][] temp = new int[n][n];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j <n ; j++) {
                if(i==0)
                temp[i][j]=1;
                else
                    temp[i][j]=0;
            }
        }


        for (int i = 0; i < temp.length; i++) { //this equals to the row in our matrix.
            for (int j = 0; j < temp[i].length; j++) { //this equals to the column in each row.
                System.out.print(temp[i][j] + " ");
            }
            System.out.println(); //change line on console as row comes to end in the matrix.
        }


        NodeIDS initialNode=new NodeIDS(temp.length);
        initialNode.state=temp;
        boolean con=true;

        boolean succses=false;
        do {
            System.out.println("choose 1 to apply IDS");
            int choice= input.nextInt();

            switch (choice){

                case 1:
                IDS depth=new IDS(initialNode);
                    succses=depth.iterative_deeping();
                break;
                case 2:
                    con=false;


            }



        }while (con==false);




    }
}
