import java.util.List;
import java.util.Stack;
import java.util.Queue;


public class IDS  {
    private NodeIDS initialNode;

    Stack<NodeIDS> nodeList = new Stack<>();
    public IDS(NodeIDS node) {
        this.initialNode = node;
    }


    public boolean iterative_deeping() {
        InfoIDS info = new InfoIDS();
        NodeIDS node = initialNode;
        int depth=1;
        boolean succses = false;
        int c=0;
        while (c<10000){
            succses=depth_limted(depth,node,info);
            if (succses)
                break;
            depth++;
            c++;
        }
        return succses;
    }
    public boolean depth_limted(int depth,NodeIDS node,InfoIDS info) {


        InfoIDS frontier = new InfoIDS();


        frontier.stack.push(node);
        while (!(frontier.stack.empty()) ) {
            node = frontier.stack.pop();
            info.incTime();
            info.visited.put(node.hashCode(), node);//places node in visited hashMap

            if (node.isGoal()) {
                PathActionsIDS p=new PathActionsIDS(initialNode,node,info);
                p.printPath();
                return true;
                //increment number of nodes
            }
            if(node.depth <= depth) {
                ExpandedIDS e = new ExpandedIDS();
                Stack<NodeIDS> list = e.expand(node);

                nodeList.push(node);

                //boolean ans1 = checkIfvisited(node);
                //if (ans1 == false)
                    //continue;

                while (!list.empty()) {
                    NodeIDS temp = list.pop();
                    boolean ans = info.visited.containsKey(temp.hashCode());//hash code is the internal address of object
                    if (ans == false) {
                        if (!frontier.stack.contains(temp)) {
                            frontier.stack.push(temp);
                            info.stackSize();
                        }
                    }

                }
            }

    }
        return false;
    }
    public boolean checkIfvisited(NodeIDS node){
        int count=0;
        while (!nodeList.empty()){
            NodeIDS n=nodeList.pop();
            for (int i = 0; i <node.state.length ; i++) {
                for (int j = 0; j <node.state.length ; j++) {
                    if(n.state[i][j]==node.state[i][j])
                        count++;
                }
            }
            if(count==node.state.length*node.state.length)
                return false;
        }

        return true;
    }
}
