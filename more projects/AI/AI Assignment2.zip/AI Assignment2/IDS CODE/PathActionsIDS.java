
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PathActionsIDS {
    // this class provides an object that is used to trace back the path from the goal
    // it then prints the path
    List<NodeIDS> path;
    InfoIDS info; //info object is used in order to print details about space and time

    public PathActionsIDS(NodeIDS initialNode, NodeIDS goalNode, InfoIDS inf) {  //the arguments are goalNode, info and intialNode so a path can be found.
        path = this.getPath(initialNode, goalNode);
        this.info = inf;
    }


    private List<NodeIDS> getPath(NodeIDS initialNode, NodeIDS goalNode) {  //given a goalNode and initialNode this method uses node's parents to trace it's way back up
        NodeIDS tempNode = goalNode;
        List<NodeIDS> list = new ArrayList<>();

        while(!(tempNode.equals(initialNode))) {
            list.add(tempNode);
            tempNode = tempNode.getParent();

        }
        list.add(initialNode);
        return list;  // a list of the path is returned in reverse order
    }


    public void printPath() {   //this method enables us to print the path in correct order from start node to goal node with sufficient details.
        int size = path.size();

        for(int i= size-1;i>=0;i--) {
            System.out.println();
            System.out.println();
            System.out.println("Depth: " + path.get(i).getDepth());
            System.out.println("Cost: " + path.get(i).getCost());
            System.out.println("MaxCost: " + path.get(i).getMaxCost());
            System.out.println();
            System.out.println("Current Node: \n");
            System.out.println(Arrays.deepToString(path.get(i).getMatrix()).replace("], ", "]\n").replace("[[", "[").replace("]]", "]"));
            System.out.println();
        }
        System.out.println("Time: " + info.getTime());
        System.out.println("Space: " + info.getSpace());
    }

}
