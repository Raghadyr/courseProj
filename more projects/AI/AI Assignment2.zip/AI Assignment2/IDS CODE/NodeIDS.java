import java.util.ArrayList;
import java.util.List;

public class NodeIDS {
    int[][] state;
    NodeIDS[] children;
    List<NodeIDS> childrenList;
    NodeIDS parent;
    int depth;
    int cost;
    int maxCost;

    public NodeIDS(int n) {
        children = new NodeIDS[n];
        this.depth = 0; // the depth
        state=new int[n][n];
        this.childrenList = new ArrayList<>(); //the children of the node
        this.parent = null;
        this.cost = 0;
        this.maxCost = 0;


    }

    public boolean isGoal() {
        boolean flag = false;
        int queenNum=0;
       /* for (int i = 0; i < state.length; i++) { //this equals to the row in our matrix.
            for (int j = 0; j < this.state[i].length; j++) { //this equals to the column in each row.
                System.out.print(this.state[i][j] + " ");
            }
            System.out.println(); //change line on console as row comes to end in the matrix.
        }*/
        for (int i = 0; i < state.length; i++) {
            for (int j = 0; j < state.length; j++) {
                if (this.state[i][j] == 1){
                flag = isAttacked(this.state, i, j,state.length );
                if (!flag)
                    queenNum++;
            }

            }

        }
        System.out.println(queenNum);
        return queenNum == state.length;
    }



    public boolean isAttacked(int[][] x, int r, int c, int N)
    {

        for(int i =0;i<N;i++)
        {
            if(x[r][i]==1 && i!=c){
                return true;
            }
        }

        for(int i =0;i<N;i++)
        {
            if(x[i][c]==1 && i!=r){
                return true;
            }
        }

        for(int i=0;i<N;i++)
        {
            for(int j=0;j<N;j++)
            {
                int a = Math.abs(r-i);
                int b = Math.abs(c-j);
                if(a==b && x[i][j]==1 &&i!=r && j!=c){
                    return true;
                }
            }

        }
        return false;
    }
/*
    public void createChild(int n,Node node) {
        int[][] tem={{0,1,0,0},{0,0,0,1},{1,0,0,0},{0,0,1,0}};
        int[][] temp = new int[state.length][state.length];
        /*temp =state; <- we dont want our code to copy the address and make change so that why we will use loop to transfer the elements


        for (int a = 0; a < state.length; a++) {
            System.arraycopy(node.state[a], 0, temp[a], 0, state.length);
        }

        for (int i = 0; i < n; i++) {


            for (int j = 0; j < temp.length-1; j++) {
                if(temp[j][i] == 1) {
                    temp[j + 1][i] = temp[j][i];
                    temp[j][i] = 0;
                    break;
                }
            }

            node.children[i] = new Node(state.length);
            for (int a = 0; a < state.length; a++) {
                for (int b = 0; b < state.length; b++) {
                    node.children[i].state[a][b]=temp[a][b];
                }
            }

            node.children[i].setCost(node.cost);
            node.addChild(node.children[i]);
            //temp= new Integer[][]{{1, 1, 1, 1}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}};
            for (int a = 0; a < state.length; a++) {
                System.arraycopy(node.state[a], 0, temp[a], 0, state.length);
            }

            for (int b = 0; b < state.length; b++) { //this equals to the row in our matrix.
                for (int c = 0; c < state.length; c++) { //this equals to the column in each row.
                    System.out.print(node.children[i].state[b][c] + " ");
                }
                System.out.println(); //change line on console as row comes to end in the matrix.
            }

        }
        /*
        for (int j = 0; j < n; j++) {//shift one coulem dawn

            for (int i = 0; i < n - 1; i++) {

                if (children[j].state[i][j] == 1) {
                    children[j].state[i + 1][j] = state[i][j];
                    children[j].state[i][j] = 0;
                    break;
                }
                }



        }*/



    public void addChild(NodeIDS child) { //adding a Child to the node
        child.setParent(this);
        child.setDepth(this.getDepth() + 1);
        child.setMaxCost(child.getCost());
        this.childrenList.add(child);

    }

    public void setCost(int i) {                    //setting cost
        this.cost = i;
    }

    public void setMaxCost(int i) {
        this.maxCost = this.getParent().getMaxCost() + i;            //setting MaxCost
    }

    public int[][] getMatrix() { //getting the state in array form
        return state;
    }

    public int getMaxCost() { //getting the current MaxCode to get to current Node
        return maxCost;
    }

    public int getCost() { //getting the cost of last move
        return this.cost;
    }

    public void setParent(NodeIDS parent) { //setting the Parent of the node
        this.parent = parent;
    }

    public NodeIDS getParent() {  //getting the Parent of the node
        return parent;
    }

    public int getDepth() {  //getting the Depth of the node
        return depth;
    }

    public void setDepth(int depth) {  //setting the Depth of the node
        this.depth = depth;
    }




}
// first make the initial state then at each itriation we will genrate new seccsessors check wither they are in the explored
//now how to genrate the seccsesors
//intial state all the qeen are in the first row
//then at evry child the queen will move once at the same colom